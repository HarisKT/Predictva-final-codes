var firebaseConfig = {
    ....
    ....
    ....
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  var database = firebase.database();
  firebase.auth.Auth.Persistence.LOCAL;

  $("#btn-login").click(function(){
      var email=$("#email").val();
      var password=$("#password").val()
      if(email !="" && password!=""){
          var result=firebase.auth().signInWithEmailAndPassword(email,password);
          result.catch(function(error){
              var errorCode=error.code;
              var errorMessage=error.message;

              console.log(errorCode);
              console.log(errorMessage);

              window.alert("Message: " +errorMessage);
              
          });
      }
      else{
          window.alert("Form is incomplete. Please fill out all details");
         // window.location.href="home.html";
      }
  });



$("#btn-signup").click(function(){
    var email=$("#email").val();
    var password=$("#password").val()
    var cpassword=$("#confirmPassword").val()
    if(email !="" && password!="" && cpassword!=""){
        if(password == cpassword){
            var result=firebase.auth().createUserWithEmailAndPassword(email,password);
            result.catch(function(error){
            var errorCode=error.code;
            var errorMessage=error.message;

            console.log(errorCode);
            console.log( errorMessage);

            window.alert("Message: " +errorMessage);
            
        });
        } 
        else{
            window.alert("Password do not match with the confirm password");
        }
    }
    else{
        window.alert("Form is incomplete. Please fill out all details");
    }
});




$("#btn-resetpassword").click(function(){
    var auth=firebase.auth();
    var email=$("#email").val();

    if(email!=""){
         auth.sendPasswordResetEmail(email).then(function(){
            
            window.alert("Email has been sent to you, please check and verify.");
         })
         .code(function(error){
            var errorCode=error.code;
            var errorMessage=error.message;

            console.log(errorCode);
            console.log( errorMessage);

            window.alert("Message: " +errorMessage);
         });
    }
    else{
        window.alert("please write your email first.");
    }
});

$("#btn-logout").click(function(){
    firebase.auth().signOut();
});


$("#btn-update").click(function(){
   var phone=$("#phone").val();
   var address=$("#address").val();
   var bio=$("#bio").val();
   var fname=$("#firstName").val();
   var sname=$("#secondName").val();
   var country=$("#country").val();
   var gender=$("#gender").val();

   var rootRef=firebase.database().ref().child("Users")
   var userID=firebase.auth().currentUser.uid;
   var userRef=rootRef.child(userID);

   if(fname!="" && sname!="" && phone!="" && country!="" && gender!="" &&bio!="" && address!=""){
    var userData={
        "phone":phone,
        "address":address,
        "bio":bio,
        "firstName":fname,
        "secondName":sname,
        "country":country,
        "gender":gender,
        };
        userRef.set(userData,function(error){
            if(error){
                var errorCode=error.code;
                var errorMessage=error.message;
    
                console.log(errorCode);
                console.log( errorMessage);
    
                window.alert("Message: " +errorMessage);
            }
            else{
                window.location.href="home.html";
            }
        });
   }
   else{
       window.alert("Form is incomplete. Please fill out all fields")
   }
});



/*$("#save-blog").click(function(){
   
    var pin=$("#pin").val();
    var threshold=$("#thresholdvalue").val();
  
 
    var rootRef=firebase.database().ref().child("Temperature Sensor")
    var userID=firebase.auth().currentUser.uid;
    var userRef=rootRef.child(userID);
 
    if(threshold!=""  && pin!=""){
     var userData={
         
         "pin":pin,
         "threshold":threshold,
        
         };
         userRef.set(userData,function(error){
             if(error){
                 var errorCode=error.code;
                 var errorMessage=error.message;
     
                 console.log(errorCode);
                 console.log( errorMessage);
     
                 window.alert("Message: " +errorMessage);
             }
             else{
                 window.location.href="MainPage.html";
             }
         });
    }
    else{
        window.alert("Form is incomplete. Please fill out all fields")
    }
 });*/
    /*ref.on("value", function(snapshot) {
       for (x in snapshot.val()) {
            var xRef = Firebase.database().ref().child("sensors"+x+"/I2C");//;+x+"/I2C");
            xRef.once("value", function(xsnapshot) {
                var name = xsnapshot.child("temp");
                console.log(name);
            });
        }
    }, function (errorObject) {
        console.log("The read failed: " + errorObject.code);
    });*/
   /* ref.on("child_added",snap =>{
        var temp=snap.child("temp").val();
        console.log(temp);
    });*/

   /* const db = Firebase.database();
    //firebase.on("value", function(snapshot) {
       // for (x in snapshot.val()) {
             var xRef = Firebase.database().ref().child("object");
             xRef.on('value',snap => console.log(snap.val()));
             firebase.database().ref('object').on('value',(snap)=>{
             console.log(snap.val());
         //  });
         
         //}
     }, function (errorObject) {
         console.log("The read failed: " + errorObject.code);
     });


     db.collection("object").get().then(function(querySnapshot) {
        querySnapshot.forEach(function(doc) {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data());
        });
    });*/

   /* const database=firebase.database();
    var leadsRef = database.ref('Sensor');
    leadsRef.on('value', function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
      var childData = childSnapshot.val();
      console.log("succesful");
    });
});*/


         /*   var database=firebase.database();
            var firedata=new Array();
            var i=0;
            console.log(firedata.length);  

            console.log("succesful");    
                var leadsRef =database.ref("sensor/I2C");
                leadsRef.limitToLast(1).on('value', function(snapshot) {
                snapshot.forEach(function(childSnapshot) {
                  var childData = childSnapshot.val();
                    firedata.push(childData);
                    for(i=0;i<firedata.length;i++){
                        console.log(firedata[i]); 
                    }
                    console.log(firedata.length); 
                   // console.log("succesful");
                  //  console.log(childData);
                });
});*/
                


    
    
    

 






 



